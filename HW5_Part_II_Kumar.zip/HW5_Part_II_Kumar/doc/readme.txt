Readme.txt


URL TO VISIT :

REACT : https://react-ms-djynsqi6wa-uc.a.run.app/
FLASK : https://flask-ms-upljshkjtq-uc.a.run.app

There are 3 main components inside the code folder that was given to us under the section of “tutorial 16”.

Inside the “code folder”, we have 3 subfolders.

Flask
LSTM-forecast
React

For each of the folders, we need to make a project inside the Google cloud or known as GCP.

After doing the project creation at GCP for all the folders, we need to execute a series of commands and general steps.

First, we need to enable the container-registry API. This will help us to connect the project with docker; this is significantly important when we are required to push the docker image to google cloud.
The second step is to enable the cloud-run API. This is the console in which all the deployments are listed. 
Now we need to open the “code folder” locally in any CLI.
a. Now open the Flask project in the CLI and add the URL of your LSTM-forecast project (created on the Google cloud). Screenshot attached below.
b. Now open the React project in the CLI and add the URL of your flask project (created on the Google cloud).

In lstm-ms go to the cloud storage click on browser and click on create bucket and name your bucket. The bucket name should be unique. Then after that select location type and in that select region. The location will be us-central1(lowa) and then we click on continue.
5. After the above step choose the storage class of the data. Click on standard and click on continue.
6. In the next step we need to choose how to control access to objects ->choose how to protect object data-> select protection tools -> select None-> click on create respectively. The above process will create a bucket.
7. Now click on your bucket name and select this and give public access. 
To make access as public access, go to add principal. A dialog box opens then select all Users.
Go to select a role dialog box, then go to cloud storage and select Storage Object Viewer. Then click on save
Next a dialog box opens, which asks for permission to allow public access to resource. Then click on Allow public access. After this step we need to go to bucket and copy the name of the bucket on notepad/sticky notes.

11. After this whole process go to readme of lstm-forecasting. Go to step 3 and click on the link given. After clicking on the link a page opens which opens the page of creating a service account. Click on “Create a service account” and select lstm-ms project. 
After the above step fill the service account details and give the name of the service account as “ lstm-ms” and service account id as “lstm-ms”. Click on create and continue.
After this go to “grant this service account access to project”. Select the role as “Owner” and click on continue. Now we do not need to make any changes in “grant users access to this service account”. Lastly click on Done.
In “Service Accounts” we can see the details of service account. Here we can see options of details, permissions, keys, matrix and logs. Click on keys and click on Add Keys-> click on create new key-> select key type JSON-> click on Create.
Download the file of key in LSTM-forecast. Lastly click on close.
Open the LSTM-forecast folder and you can see the JSON file.
Go to the readme file of LSTM-forecast, copy the command in step 7 “set GOOGLE_APPLICATION_CREDENTIALS= KEY_PATH” AND paste it in terminal of LSTM-forecast. After pasting the command replace the “KEY_PATH” with JSON file path and click enter.

8. Common Steps for LSTM-forecast, React and Flask
9. Go to terminal/ Cmd and follow the steps:-
Type docker
Type docker build . and press enter. This creates a docker image.
Type docker images. We can see the image  with its id  that is newly created.
Type docker tag<new image id>/gcr.io/Project-id/Project-name
Type gcloud init
After this step select re-initialize configuration [default] with new settings.
Enter the gmail account to perform operations
Select the desired cloud project to use
Type gcloud auth configure-docker and press enter.
Type docker images again and press enter.
Type docker push and <repository tag> and press enter. This command will push your code to gcloud
Go back to your project and go to “Container Registry”. Now we will be able to see the repository folder. Click on it and then we will be able to see the docker image we pushed. For the docker image click on deploy to cloud run.
Select the container image URL and then a dialog box will be opened and there we can select the latest image id we pushed.
Make minimum no of instances from 1 to 100 and allow unauthenticated innovations.
Go to Container, Variables and Secrets, Connections, Security. There change the memory size from 512 GB to 1GB for all three repositories of LSTM-forecast, React and Flask respectively.
 Only For LSTM-forecast and Flask Project
a. Go to Variables in Container, Variables and Secrets, Connections, Security then go to Add Variable.
For LSTM-Forecast:-
Open readme of LSTM-forecast, and copy the things mentioned in step 10. Paste them in the variables name and values respectively. 
 For Flask:-
Change container port from 8080 to 5000.
Open readme of flask and copy the github Token mentioned in step 11.
Open github and copy the new generated token in the variables name and values. 
Paste them in the variables name and values respectively. 
For React:-
Change the container port from 8080 to 3000

 Finally Click on create and cloud run will host your application.
